WiFi Signal Detection — Prototype
Files:
- index.html: website with Home, Demo Signal Check, Report an Area, Dashboard.
How to run:
1. Extract this ZIP.
2. Open index.html in Chrome, Edge, or Firefox.
3. No installation is required.
Important limitations:
- Signal values are demo inputs, not live WiFi measurements.
- Reports are stored in the current page session only; no backend/database is connected.
- Map button opens a general Google Maps search for the typed location. It does not display measured WiFi coverage.
Next steps:
- Add a backend/database.
- Connect a device or approved application that can read actual WiFi signal RSSI.
- Conduct and document tests with at least three real testers.
